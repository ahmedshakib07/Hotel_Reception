create database myHotel

create table rooms
(
roomid int Identity(1, 1) primary key,
roomNo varchar(50) not null unique,
roomType varchar(50) not null,
bed varchar(50) not null,
price bigint not null,
booked varchar(50) default 'NO'
);


select * from rooms
roomNo,roomType,bed,price


create table customer
(
cid int Identity(1, 1) primary key,
cname varchar(50) not null,
mobile bigint not null,
nationality varchar(50) not null,
gender varchar(50) not null,
dob varchar(50) not null,
idproof varchar(50) not null,
addres varchar(150) not null,
checkin varchar(50) not null,
checkout varchar(50),
chekout varchar(50) not null default 'NO',
roomid int not null,
foreign key (roomid) references rooms(roomid)
);

select * from customer