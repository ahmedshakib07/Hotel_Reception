create table employee
(
eid int Identity(1, 1) primary key,
ename varchar (50) not null,
mobile bigint not null,
gender varchar (50) not null,
emailid varchar (50) not null,
username varchar (50) not null,
pass varchar (50) not null,
);
 
 
select * from employee
ename, mobile, emailid, username,pass